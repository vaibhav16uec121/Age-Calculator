# Age-Calculator

It will take Date of Birth from EditText view and calculate total time between current System time and DateOfBirth.

And Displays Age in Years,Months and Days : )
